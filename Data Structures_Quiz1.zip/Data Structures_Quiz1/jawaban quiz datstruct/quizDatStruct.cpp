#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>
#define SIZE 120


struct Order{
	char id[4];
	char name[50];
	char category[20];
	char type[10];
	int price;
	int quantity;
	Order *next,*prev;
}*OrderHead[SIZE],*OrderTail[SIZE];

Order *createOrder(char *id, char *name, char *category, char *type, int price,int quantity){
	Order *temp = (Order*)malloc(sizeof(Order));
	
	strcpy(temp->id,id);
	strcpy(temp->name,name);
	strcpy(temp->category,category);
	strcpy(temp->type,type);
	temp->price = price;
	temp->quantity = quantity;
	temp->next = temp->prev = NULL;
	
	return temp;
}

int hashFunction(char *id){
	int len = strlen(id);
	int sum = 0;
	for(int i=0;i<len;i++){
		sum += id[i];
	}
	return sum % SIZE;
}

void insertOrder(Order *newOrder, int key){
	if(OrderHead[key] == NULL){
		OrderHead[key] = OrderTail[key] = newOrder;
	}
	else {
		OrderTail[key]->next = newOrder;
		newOrder->prev = OrderTail[key];
		OrderTail[key] = newOrder;
	}
}

Order *searchOrder(char *name){
	char key[50];
	strcpy(key,name);
	
	if(OrderHead[key[50]] != NULL){
		
		strcpy(curr,key);
		while(curr){
			if(strcmp(curr->name, name) == 0){
				return curr;
				break;
			}
			
			curr = curr->next;
		}
	}
	return NULL;
}

bool isValidName (char *name){
	if(strlen(name) >= 5 && strlen(name) <= 20 ){
		return true;
	} 
	return false;
}

bool isValidType (char *type){
	if(strcmp(type, "Baby") == 0 || 
	strcmp(type, "Adult") == 0){
		return true;
	}
	return false;
}

bool isValidCate (char *category){
	if(strcmp(category, "Food") == 0 ||
	strcmp(category, "Accessories") == 0 || 
	strcmp(category, "Treatment") == 0){
		return true;
	}
	return false;
}

void insertMenu(){
	char name[50];
	char type[20];
	char category[20];
	int price;
	int quantity;
	char id[7];
	do{
		printf("Input product name [Must be Unique and 5..20] : ");
		scanf("%[^\n]", name);
		getchar();
	}while(!isValidName(name));
	
	do{
		printf("Input product category [Food | Treatment | Accessories] : ");
		scanf("%s", category);
		getchar();
	}while(isValidCate(category) == false);
	
	do{
		printf("Input age type [Baby | Adult] : ");
		scanf("%s", type);
		getchar();
	}while(!isValidType(type));
	
	do{
		printf("Input Price[50...150] : ");
		scanf("%d", &price);
		getchar();
	}while(price >=50 || price <= 150);
	
	do{
		printf("Input Quantity[1...9] : ");
		scanf("%d", &quantity);
		getchar();
	}while(quantity >=1 || quantity <= 9);
	
	for(int i = 0; i < 2; i++){
		if(name[i] >= 'A' && name[i] <= 'Z'){
			id[i] = name[i];
		}
		else if(name[i] >= 'a' && name[i] <= 'z'){
			id[i] = name[i] - 32;
		}
	}
	for (int i = 3; i < 6; i ++){
		int n= rand() % 10;
		id[i] = n + '0';
	}
	id[6] = '\0';
	insertOrder(createOrder(id,name,category,type,price,quantity), hashFunction(id));
	puts("Insert Order Success!");
}

void viewOrder(){
	for (int i=0;i<SIZE;i++){
		if(OrderHead[i]!= NULL){
			Order *curr = OrderHead[i];
			printf("MY ORDER\n");
			printf("No		Name		Category		Age Type		Price		Quantity\n");
			while(curr){
				printf("%s		%s		%s		%s		$%d		%d\n", curr->id, curr->name, curr->category, curr->type, curr->price, curr->quantity);

				curr = curr->next;
			}
		}
		else{
			printf("No Order Yet.\n");
		}
	}
}

void checkOrder(){
	char name[50];
	printf("Input Product Name : ");
	scanf("%[^\n]",name);
	getchar();
	
	Order *toBeChecked = searchOrder(name);
}

int main(){
	
	int choice;
	do{
		printf("Bluejack Pet Shop\n");
		printf("=====================\n");
		printf ("1. Insert New Order\n");
		printf ("2. View My Order\n");
		printf ("3. Checkout My Order\n");
		printf ("4. Exit\n");
		printf("Choice = ");
		scanf("%d", &choice);
		getchar();
		
		if (choice == 1){
			insertMenu();
		}
		else if(choice == 2){
			viewOrder();
		}
		else if(choice == 3){
			checkOrder();
		}
	}while (choice != 4);
	
	
	return 0;
}
